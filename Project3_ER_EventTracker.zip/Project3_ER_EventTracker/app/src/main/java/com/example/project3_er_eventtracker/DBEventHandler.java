package com.example.project3_er_eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBEventHandler extends SQLiteOpenHelper {

    // constant variables for database.
    // database name.
    private static final String DB_NAME = "eventdb";

    // database version
    private static final int DB_VERSION = 1;

    // table name.
    private static final String TABLE_NAME = "myevents";

    // id column.
    private static final String ID_COL = "id";

    // event name column
    private static final String NAME_COL = "name";

    // event date.
    private static final String DATE_COL = "date";

    // event description column.
    private static final String DESCRIPTION_COL = "description";

    // event time column.
    private static final String TIME_COL = "time";

    // constructor for database handler.
    public DBEventHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // method for creating a database by running a sqlite query
    public void onCreate(SQLiteDatabase db) {
        // sqlite query and setting column names
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + DATE_COL + " TEXT,"
                + DESCRIPTION_COL + " TEXT,"
                + TIME_COL + " TEXT)";
        db.execSQL(query);
    }

    // Adds new event to database.
    public void addNewEvent(String eventName, String eventDate, String eventDescription, String eventTime) {

        // variable for database and calling writable method
        // writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // variable for content values.
        ContentValues values = new ContentValues();

        // passing all values along with its key and value pair
        values.put(NAME_COL, eventName);
        values.put(DATE_COL, eventDate);
        values.put(DESCRIPTION_COL, eventDescription);
        values.put(TIME_COL, eventTime);

        // passing content values to table.
        db.insert(TABLE_NAME, null, values);

        // closing database after adding database.
        db.close();
    }

    // reading all the events method.
    public ArrayList<eventModal> readEvents()
    {
        // creating a database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // cursor with query to read data from database.
        Cursor cursorEvents
                = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        // creating a new array list.
        ArrayList<eventModal> eventModalArrayList
                = new ArrayList<>();

        // moving cursor to first position.
        if (cursorEvents.moveToFirst()) {
            do {
                //  adding the data from cursor to array list.
                eventModalArrayList.add(new eventModal(
                        cursorEvents.getString(1),
                        cursorEvents.getString(4),
                        cursorEvents.getString(2),
                        cursorEvents.getString(3)));
            } while (cursorEvents.moveToNext());
            // moving cursor to next.
        }
        // closing cursor and returning array list.
        cursorEvents.close();
        return eventModalArrayList;
    }

    // method for updating events
    public void updateEvent(String originalEventName, String eventName, String eventDescription,
                             String eventTime, String eventDate) {

        // method to get writable database.
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // passing all values along with its key and value pair.
        values.put(NAME_COL, eventName);
        values.put(DATE_COL, eventDate);
        values.put(DESCRIPTION_COL, eventDescription);
        values.put(TIME_COL, eventTime);

        // update method to update database and passing values.
        // comparing it with name of event which is stored in original name variable.
        db.update(TABLE_NAME, values, "name=?", new String[]{originalEventName});
        db.close();
    }

    // method for deleting our course.
    public void deleteEvent(String eventName) {

        // creating a variable to write our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // method to delete event and comparing it with event name.
        db.delete(TABLE_NAME, "name=?", new String[]{eventName});
        db.close();
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}