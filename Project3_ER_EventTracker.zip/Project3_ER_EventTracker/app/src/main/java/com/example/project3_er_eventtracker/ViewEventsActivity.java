package com.example.project3_er_eventtracker;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import android.telephony.SmsManager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewEventsActivity extends AppCompatActivity {

    // creating variables for our array list,
    // dbhandler, adapter and recycler view.
    private ArrayList<eventModal> eventModalArrayList;
    private DBEventHandler dbHandler;
    private EventRVAdapter eventRVAdapter;
    private RecyclerView eventsRV;
    private ImageButton addEventsBtn, smsBtn;
    private static boolean smsAuthorized = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_events);

        // initializing all variables.
        eventModalArrayList = new ArrayList<>();
        dbHandler = new DBEventHandler(ViewEventsActivity.this);
        addEventsBtn = findViewById(R.id.addButton);
        smsBtn = findViewById(R.id.SMSButton);
        String phoneNo = "";
        String message = "One of your events is happening soon! Please see event list for more details.";

        // getting event array
        // list from db handler class.
        eventModalArrayList = dbHandler.readEvents();

        // passing our array list to adapter class.
        eventRVAdapter = new EventRVAdapter(eventModalArrayList, ViewEventsActivity.this);
        eventsRV = findViewById(R.id.idRVEvents);

        // setting layout manager for recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewEventsActivity.this, RecyclerView.VERTICAL, false);
        eventsRV.setLayoutManager(linearLayoutManager);

        // setting adapter to recycler view.
        eventsRV.setAdapter(eventRVAdapter);

        addEventsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a new activity via a intent.
                Intent i = new Intent(ViewEventsActivity.this, AddEventActivity.class);
                startActivity(i);
            }
        });

        // Shows alert dialog to get users preference on SMS notifications
        smsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the object of AlertDialog Builder class
                AlertDialog.Builder builder = new AlertDialog.Builder(ViewEventsActivity.this);

                // Set the message
                builder.setMessage("This app feature requires permission to be notified if you have an" +
                        " upcoming event. This feature can be enabled and disabled at any time.");

                // Set Alert Title
                builder.setTitle("SMS Permission Needed");

                // when the user clicks on the outside the Dialog Box then it will remain open
                builder.setCancelable(false);

                // Set SMS approve button
                builder.setPositiveButton("Approve", (DialogInterface.OnClickListener) (dialog, which) -> {
                    Toast.makeText(ViewEventsActivity.this, "SMS Alerts Enabled", Toast.LENGTH_SHORT).show();
                    smsAuthorized = true;
                    // Sms message
                    SmsManager smsManager=SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNo,null,message,null,null);
                    Toast.makeText(getApplicationContext(),"Message Sent",Toast.LENGTH_LONG).show();
                    dialog.cancel();
                });

                // Set up SMS deny button
                builder.setNegativeButton("Deny", (DialogInterface.OnClickListener) (dialog, which) -> {
                    Toast.makeText(ViewEventsActivity.this, "SMS Alerts Disabled", Toast.LENGTH_SHORT).show();
                    smsAuthorized = false;
                    // If user click no then dialog box is canceled.
                    dialog.cancel();
                });

                // Create the Alert dialog
                AlertDialog alertDialog = builder.create();
                // Show the Alert Dialog box
                alertDialog.show();
            }
        });



    }
}