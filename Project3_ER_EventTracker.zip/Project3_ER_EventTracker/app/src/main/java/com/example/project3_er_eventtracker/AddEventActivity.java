package com.example.project3_er_eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    // creating variables for edittext, button and dbhandler
    private EditText eventNameEdt, eventTimeEdt, eventDateEdt, eventDescriptionEdt;
    private Button addEventBtn, readEventBtn;
    private DBEventHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // initializing variables.
        eventNameEdt = findViewById(R.id.idEdtEventName);
        eventTimeEdt = findViewById(R.id.idEdtEventTime);
        eventDateEdt = findViewById(R.id.idEdtEventDate);
        eventDescriptionEdt = findViewById(R.id.idEdtEventDescription);
        addEventBtn = findViewById(R.id.idBtnAddEvent);
        readEventBtn = findViewById(R.id.idBtnReadEvent);

        // creating a new dbhandler class and passing our context to it.
        dbHandler = new DBEventHandler(AddEventActivity.this);

        // add on click listener for our add event button.
        addEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // get data from all edit text fields.
                String eventName = eventNameEdt.getText().toString();
                String eventTime = eventTimeEdt.getText().toString();
                String eventDate = eventDateEdt.getText().toString();
                String eventDescription = eventDescriptionEdt.getText().toString();

                // validating if the text fields are empty or not.
                if (eventName.isEmpty() && eventTime.isEmpty() && eventDate.isEmpty() && eventDescription.isEmpty()) {
                    Toast.makeText(AddEventActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // method to add new event to data and pass all values to it.
                dbHandler.addNewEvent(eventName, eventDate, eventDescription, eventTime);

                // displaying a toast message that event was added.
                Toast.makeText(AddEventActivity.this, "Event has been added.", Toast.LENGTH_SHORT).show();
                eventNameEdt.setText("");
                eventDateEdt.setText("");
                eventTimeEdt.setText("");
                eventDescriptionEdt.setText("");
            }
        });

        readEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a new activity via a intent.
                Intent i = new Intent(AddEventActivity.this, ViewEventsActivity.class);
                startActivity(i);
            }
        });

    }
}