package com.example.project3_er_eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UpdateEventActivity extends AppCompatActivity {

    // variables for edit text, button, strings and dbhandler class.
    private EditText eventNameEdt, eventTimeEdt, eventDateEdt, eventDescriptionEdt;
    private Button updateEventBtn, deleteEventBtn;
    private DBEventHandler dbHandler;
    String eventName, eventDesc, eventDate, eventTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_event);

        // initializing variables.
        eventNameEdt = findViewById(R.id.idEdtCurrEventName);
        eventTimeEdt = findViewById(R.id.idEdtCurrEventTime);
        eventDateEdt = findViewById(R.id.idEdtCurrEventDate);
        eventDescriptionEdt = findViewById(R.id.idEdtCurrEventDescription);
        updateEventBtn = findViewById(R.id.idBtnUpdateEvent);
        deleteEventBtn = findViewById(R.id.idBtnDelete);

        // initializing dbhandler class.
        dbHandler = new DBEventHandler(UpdateEventActivity.this);

        // getting data
        eventName = getIntent().getStringExtra("name");
        eventDesc = getIntent().getStringExtra("description");
        eventDate = getIntent().getStringExtra("date");
        eventTime = getIntent().getStringExtra("time");

        // setting data to edit text
        eventNameEdt.setText(eventName);
        eventDescriptionEdt.setText(eventDesc);
        eventTimeEdt.setText(eventTime);
        eventDateEdt.setText(eventDate);

        // adding on click listener to our update event button.
        updateEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // calling an update event method and passing all edit text values.
                dbHandler.updateEvent(eventName, eventNameEdt.getText().toString(), eventDescriptionEdt.getText().toString(), eventTimeEdt.getText().toString(), eventDateEdt.getText().toString());

                // displaying a toast message that event has been updated.
                Toast.makeText(UpdateEventActivity.this, "Event Updated", Toast.LENGTH_SHORT).show();

                // launching our viewEvents activity.
                Intent i = new Intent(UpdateEventActivity.this, ViewEventsActivity.class);
                startActivity(i);
            }
        });

        // adding on click listener for delete button to delete event.
        deleteEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // calling a method to delete event.
                dbHandler.deleteEvent(eventName);
                Toast.makeText(UpdateEventActivity.this, "Deleted the course", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateEventActivity.this, ViewEventsActivity.class);
                startActivity(i);
            }
        });
    }
}