package com.example.project3_er_eventtracker;

public class eventModal {
    // variables for eventname,
    // description, time and date, id.
    private String eventName;
    private String eventDate;
    private String eventTime;
    private String eventDescription;
    private int id;

    // getter and setter methods
    public String getEventName() { return eventName; }

    public void setEventName(String eventName)
    {
        this.eventName = eventName;
    }

    public String getEventDate()
    {
        return eventDate;
    }

    public void setEventDate(String eventDate)
    {
        this.eventDate = eventDate;
    }

    public String getEventTime() { return eventTime; }

    public void setEventTime(String eventTime)
    {
        this.eventTime = eventTime;
    }

    public String getEventDescription()
    {
        return eventDescription;
    }

    public void
    setEventDescription(String eventDescription)
    {
        this.eventDescription = eventDescription;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    // constructor
    public eventModal(String eventName,
                       String eventDate,
                       String eventTime,
                       String eventDescription)
    {
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.eventDescription = eventDescription;
    }
}
