package com.example.project3_er_eventtracker;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventRVAdapter extends RecyclerView.Adapter<EventRVAdapter.ViewHolder> {

    // variable for our array list and context
    private ArrayList<eventModal> eventModalArrayList;
    private Context context;

    // constructor
    public EventRVAdapter(ArrayList<eventModal> eventModalArrayList, Context context) {
        this.eventModalArrayList = eventModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // on below line we are inflating our layout
        // file for our recycler view items.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // setting data to views of recycler view item.
        eventModal modal = eventModalArrayList.get(position);
        holder.eventNameTV.setText(modal.getEventName());
        holder.eventDescTV.setText(modal.getEventDescription());
        holder.eventDateTV.setText(modal.getEventDate());
        holder.eventTimeTV.setText(modal.getEventTime());

        // add on click listener for recycler view item.
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // calling an intent.
                Intent i = new Intent(context, UpdateEventActivity.class);

                // passing all values.
                i.putExtra("name", modal.getEventName());
                i.putExtra("description", modal.getEventDescription());
                i.putExtra("date", modal.getEventDate());
                i.putExtra("time", modal.getEventTime());

                // starting activity.
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        // returning the size of array list
        return eventModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // variables for text views.
        private TextView eventNameTV, eventDescTV, eventDateTV, eventTimeTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing text views
            eventNameTV = itemView.findViewById(R.id.idTVEventName);
            eventDescTV = itemView.findViewById(R.id.idTVEventDescription);
            eventDateTV = itemView.findViewById(R.id.idTVEventDate);
            eventTimeTV = itemView.findViewById(R.id.idTVEventTime);
        }
    }
}
